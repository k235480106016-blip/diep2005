import http.server
import socketserver
import webbrowser
import os

# Chuyển đến thư mục chứa file này
os.chdir(os.path.dirname(os.path.abspath(__file__)))

PORT = 8000

Handler = http.server.SimpleHTTPRequestHandler

print("=" * 50)
print("  🌸 BEAUDY.VN - Server đang khởi động...")
print("=" * 50)
print(f"  ✅ Truy cập tại: http://localhost:{PORT}")
print(f"  ❌ Nhấn Ctrl+C để dừng server")
print("=" * 50)

# Tự động mở trình duyệt
webbrowser.open(f"http://localhost:{PORT}/index.html")

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    httpd.serve_forever()
